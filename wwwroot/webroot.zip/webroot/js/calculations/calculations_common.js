var counter = 0;
var modoActual ='CR'
var forzar = 0;
function calcular(force,action=null){
        modoActual ='CR'
	c_action =action||c_action;
        forzar = force;
        //url = action||c_action;
        $("#msg").collapse('show')
	$("#btn_calcular").attr("disabled", true)
	$("#message_cont").collapse('show')
	$("#message").html("Calculando Cmls...")
	//Obtener datos de totales a calcular para configurar el No. de pasos
	dataPassed = {'force': forzar,'size':1,'step':1, 'modo': 'INICIAL'}
	request = $.ajax({url: c_action, processData: true, type: "get",data: dataPassed, success: function(result){
		var result_parsed = JSON.parse(result);
		$('#dataCalculos').val(result_parsed['Total Tmls'])
		$("#message").html('<b>No. Tmls a calcular: </b>' + result_parsed['Total Tmls'] + ' Tmls')
		counter = 0;
		calcularIteracion()
	},cache: false,
	contentType: false});
	request.fail(function (jqXHR, textStatus, errorThrown){
		$("#message").html('Ocurrió un error al calcular')
		$("#btn_calcular").attr("disabled", false)
	});
}

function calcularIteracion(){
        //url = action||c_action;
	step_size = 500
	totalTmlsCalc = $('#dataCalculos').val();
	NoSteps = Math.ceil(totalTmlsCalc/step_size)
	dataPassed = {'force': forzar,'size':step_size,'step':(counter), 'modo': modoActual}
	
	request = $.ajax({url: c_action, processData: true, type: "get",data: dataPassed, success: function(result){
		var result_parsed = JSON.parse(result);
		pctg = Math.round(((counter+1)/NoSteps)*100);
		$("#message").html('<b>Calculando '+modoActual+'  Estado:</b> Paso ' + (counter+1) + ' de '+  NoSteps + '.')
		$('.progress-bar').css('width', pctg+'%').attr('aria-valuenow', pctg); 
		$('.progress-bar').html('<b> '+  pctg + '%</b>'); 
		counter++;
		if (counter < NoSteps) {
			if(modoActual == 'INTEGRITY'){
				if(result_parsed['Tmls_Int_By_Group']< $('#dataCalculos').val()){
                                    $('#dataCalculos').val(result_parsed['Tmls_Int_By_Group']);
				}
			}
			if(modoActual == 'GROUP_MARKING'){
				if(result_parsed['No_Grupos']< $('#dataCalculos').val()){
                                    $('#dataCalculos').val(result_parsed['No_Grupos']);
				}
			}
			calcularIteracion();
		}else{//mensaje de Finalización
			if(modoActual =='CR') {
				counter = 0 //reiniciar el contador en cero
				modoActual = 'GROUP_CR'
				$('#dataCalculos').val(1); //Calcular todos los grupos de una sola vez
				calcularIteracion();
			}else{	
				if(modoActual == 'GROUP_CR'){
					counter = 0
					modoActual = 'INTEGRITY'
					$('#dataCalculos').val(100000); //Actualizar por No. Tmls pendientes por integridad 
					calcularIteracion();
				}else{
					if(modoActual == 'INTEGRITY'){
						counter = 0
						modoActual = 'GROUP_MARKING'
						$('#dataCalculos').val(100000); //Actualizar por No. Tmls pendientes por integridad 
						calcularIteracion();
					}else{
						$(".modal-header #myModalLabel").text( "Calculo actualizado" );
						$(".modal-body").html( "<p>Los cmls fueron calculados</p>" );
						$("#btn-action-modal").html('Recargar');
						$("#btn-action-modal").click(function() {cargarGrupo();});
						$('#modal_window').modal('show');
                                                $("#message").html('Calculo Finalizado');
						
					}
				}
			}
	}},cache: false,
	contentType: false});
	request.fail(function (jqXHR, textStatus, errorThrown){
		// Log the error

	});
	request.always(function () {
		// Reenable the inputs
	});
}