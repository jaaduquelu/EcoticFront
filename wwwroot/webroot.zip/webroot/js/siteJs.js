/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
var verde ='rgba(0, 66, 55, 1)';
var verdeClaro  ='rgba(201, 210, 0, 1)';
var amarillo = 'rgba(255, 221, 0, 1)';
var rojo = 'rgba(255, 0, 0, 1)';
var $filtros = $("#filters > option");
var sidebar_status;
var $contextMenu =  $("#contex-menu");
var sidebarStatus = localStorage.getItem("sidebar_status") || false;
var sessionFilters;
var tableLoader ="<div style='display:inline-block; background:#fff; font-weight:bold; font-size:16px; color:#000; padding:10px 20px;'><div class='d-flex align-items-center'><strong>Cargando datos...</strong><div class='clearfix'> </div><div class='spinner-border text-primary' role='status'><span class='sr-only'>Cargando datos...</span></div></div></div>"
function convertFieldToAutoComplete(campo,urlExterna,placeholder=''){
	//$input = $(".material_name");
	campo.select2({
	  placeholder: placeholder,
          width: 'resolve',
	  ajax: {
		url: urlExterna,
		data: function (params) {
		  var query = {
			term: params.term,
			q: params.term,
			cl: $("#corrosion_loop").val()
		  }
		  return query;
		},
		dataType: 'json',
		delay: 250,
		processResults: function (data) {
		  // Tranforms the top-level key of the response object from 'items' to 'results'
		  var data = $.map(data.data, function (obj) {
			  obj.text = obj.text || obj.name; // replace name with the property used for the text
			  return obj;
			});
		  return {
			results: data
		  };
		},
		cache: true,
		minimumInputLength: 3,
	}
	});
}

function depDropFields(){
    
}
function includeHierarchyFilters(paramsHierarchy){
    
    paramsHierarchy.forEach(function (currentValue, index, array){
        $(currentValue.identifier).depdrop({
            url: currentValue.url,
            depends: [currentValue.depends],
            initDepends: currentValue.initDepends
        });
        $(currentValue.identifier).on('depdrop:afterChange', function(event, id, value, count, textStatus, jqXHR) {
            if(localStorage.getItem("hierarchyFilter."+currentValue.name)>0){
                 $(this).val(localStorage.getItem("hierarchyFilter."+currentValue.name)).change();
             }
        });
        $(currentValue.identifier).on('change', function (e) {
            if ($(this).children("option:selected").val()!= null && $(this).children("option:selected").val()>0) {
                localStorage.setItem("hierarchyFilter."+currentValue.name, $(this).children("option:selected").val());
            }
        });
    });
    $(document).ready(function(){//Obtener variables de jerarquia
        /*d = localStorage.getItem("hierarchyFilter.Department");
        cl= localStorage.getItem("hierarchyFilter.CorrosionLoop");
        u = localStorage.getItem("hierarchyFilter.Unit");
        g = localStorage.getItem("hierarchyFilter.Group")
        console.log('departamento: '+d+", CL: "+cl+", Grupo:"+g)
        if((d)>0){
            //console.log(d);
             $('#departments').val(d).change();
          }
          if((u)>0){
             $('#unidades').val(u).change();
          }
          if(cl>0){
             //$('#corrosion_loop').append("<option selected value='"+cl+"'></option>");
             $('#corrosion_loop').val(cl).change();
          }
          //if(g>0){
          //   $('#grupos').append("<option selected value="+g+"> grupo</option>");
          //}
          if(cl>0 || g>0){
              cargarGrupo();
          }*/

     });
 
}
function updateSessionFilters(arrFilters,u_action,callback = null){
    dataToSend = {filters:JSON.stringify(arrFilters)}
    request = $.ajax({url: u_action, processData: true, type: "get",data: dataToSend, 
    success: function(result) {
        var result_parsed = JSON.parse(result);
            if(callback){
                callback();
            }
    },
    cache: false,
    contentType: false});
    request.fail(function (jqXHR, textStatus, errorThrown){
            // Log the error
    });
    request.always(function () {
            // Always things
    });
    
}
//Refrescar filtros
function refrescar(){
	//document.refresh();
	$("#departments").val('').change();
	$("#unidades").val('').change();
	$("#corrosion_loop").val('').change();
	$("#grupos").val('').change();
	table_data.tabulator("setData",[]);
	$("#cmls_total").html("");
	$("#cmls_plan").html("");
	$("#cmls_inspected").html("");
        $("#cr_grupo").html("");
	$("#cobertura").html("");
	$("#msg").collapse("hide");
        $("#filters option").each(function(){
            console.log(this)
        });
        loadTableData();
	//cargarGrupo(1)
}
function refrescar2(){
	//document.refresh();
	$("#departments").val('').change();
	$("#unidades").val('').change();
	$("#corrosion_loop").val('').change();
	$("#grupos").val('').change();
        table_data.setData([]);
	$("#cmls_total").html("");
	$("#cmls_plan").html("");
	$("#cmls_inspected").html("");
        $("#cr_grupo").html("");
	$("#cobertura").html("");
	$("#msg").collapse("hide");
        loadTableData();
	//cargarGrupo(1)
}
//Funcion para manejo de barra lateral
$(document).ready(function () {
    sidebar_status = JSON.parse(localStorage.getItem("sidebar_status"));
    if(sidebar_status==null){ 
        sidebar_status=true
    } else if(sidebar_status == false){ toggleSidebar();}
    $('#sidebarCollapse, #filter_icon').on('click', toggleSidebar);
    $('#filterShow').on('click', function () {toggleSidebar();});
    
});

//Funciones de dataTables
function includeContextMenu(){
    
    $(document).mouseup(function(e) 
    {
        var container = $contextMenu 

        // if the target of the click isn't the container nor a descendant of the container
        if (!container.is(e.target) && container.has(e.target).length === 0) 
        {
            $('.tabulator-row').removeClass('bg-info')
            container.hide();
        }
            $('.tabulator-row').removeClass('bg-info')
            container.hide();
    });
}

function toggleSidebar(){
    $('#sidebarDiv').toggleClass('active');
    $('#sideBarTotal').toggleClass('active');
   // alert('cambiado')
        $('#actions-sidebar').toggleClass('active');
		$('#sidebarCollapse').toggleClass("d-none d-block");
		$('#filter_icon').toggleClass("d-none d-block");
                $('#mainContent').toggleClass("col-11");
        sidebarStatus = !sidebarStatus;
        localStorage.setItem("sidebar_status",sidebarStatus)
}
function showSidebar(){
    $('#sideBarTotal').addClass("active");
    $('#actions-sidebar').addClass('active');
    console.log($("#sidebarTotal").attr('id'))
    sidebarStatus = true;
    localStorage.setItem("sidebar_status",sidebarStatus)
}


//Chart Functions
function removeDataFromChart(chart) {
    chart.data.labels.pop();
    chart.data.datasets.forEach((dataset) => {
        dataset.data.pop();
    });
    chart.update();
}
//chart_type String: bar,horizontalBar,line,radar,pie,doughnut,polarArea,bubble,scatter,area,mixed
function createGraph(data,chart_obj,div_name,title,color,chart_type = "bar",dataSetoptions = {ylabel:'# Cmls'},graphOptions={},scales={}){
    dataArray = [];
    myData =data[1]
    for (key in myData) {
            //dataArray.push(key);         // Push the key on the array
            dataArray.push(myData[key]); // Push the key's value on the array
    }
    chartO = new Chart(div_name, {
    type: chart_type,
    data: {
        labels: data[0],
        datasets: [
            {
            label: dataSetoptions.ylabel,
            data:dataArray,
            backgroundColor: color,
            borderWidth: 1
            }
        ]
    }
    });
    chart_obj.options={
        responsive: true,
    }
    /*chart_obj.options.legend = {
            display: true,
            position:'bottom',
        }*/
    if(chart_type == 'bar'){
        chartO.options = {
            title: {
            display: true,
            text: title
            }};
    }
    if(Object.keys(scales).length){
        chartO.scales = scales
    }
    if(Object.keys(graphOptions)){
        chartO.options = graphOptions
    }
	chartO.update();
	return chartO;
}
function createGraphFancy(data,chart_obj,div_name,chart_type = "bar",graphOptions={},scales={}){
    
    chartO = new Chart(div_name, {
    type: chart_type,
    data: data,
    options : graphOptions
    });

    if(Object.keys(graphOptions).length>0){
        chartO.options = graphOptions
    }
    chartO.update();
    return chartO;
}
function updateGraph(data,chart_obj,title,color,chart_type = "bar"){
	
    dataArray = [];
    myData =data[1]
    for (key in myData) {
            //dataArray.push(key);         // Push the key on the array
            dataArray.push(myData[key]); // Push the key's value on the array
    }
	
    chart_obj.type = chart_type,
    chart_obj.data= {
            labels: data[0],
            datasets: [{
                label: '# Cmls',
                data:dataArray,
                backgroundColor: color,
                borderWidth: 1
            }
            ]
        }
    /*chart_obj.options={
        responsive: true,
    }*/
    /*chart_obj.options.legend = {
            display: true,
            position:'bottom',
        }*/
    if(chart_type == 'bar'){
        chart_obj.options = {
            title: {
            display: true,
            text: title
        }};
        chart_obj.scales= {
            yAxes: [{
                ticks: {
                    beginAtZero:true
                    }
                }]
            };
    }
	//chartO.update();
	chart_obj.update();
}
function removeDataToChart(chart) {
    chart.data.labels.pop();
    chart.data.datasets.forEach((dataset) => {
        dataset.data.pop();
    });
    chart.update();
}
function addDataToChart(chart, label, data) {
    chart.data.labels.push(label);
    chart.data.datasets.forEach((dataset) => {
        dataset.data.push(data);
    });
    chart.update();
}
//Tabla de datos de cmls
TableConsultaColumns = [ //Define Table Columns
		{title:'Int Cml', field:'tml_calc_status',headerTooltip:"Estado de cálculo de Integridad del cml", width:10,headerSort:false, formatter:"tickCross",formatterParams:{ allowEmpty:true, allowTruthy:true,}},
		{title:'CR Cml', field:'tml_cr_calc_status',headerTooltip:"Estado de cálculo de Velocidad de Corrosión", width:10,headerSort:false, formatter:"tickCross",formatterParams:{ allowEmpty:true, allowTruthy:true,}},
		{title:'Car Cml', field:'tml_car_calc_status',headerTooltip:"Estado de cálculo de CAR del cml", width:10,headerSort:false, formatter:"tickCross",formatterParams:{ allowEmpty:true, allowTruthy:true,}},
		{title:'CR Gr', field:'group_cr_calc_status', width:10,headerSort:false,headerTooltip:"Estado de cálculo de velocidad de corrosión del grupo", formatter:"tickCross",formatterParams:{ allowEmpty:true, allowTruthy:true,}},
		{title:'Int Gr', field:'group_calc_status', width:10,headerSort:false,headerTooltip:"Estado de cálculo de integridad del grupo", formatter:"tickCross",formatterParams:{ allowEmpty:true, allowTruthy:true,}},
		{title:'Departamento', field:'departments-name', width:120,headerSort:false},
		{title:'Unidad', field:'units-name', width:80,headerSort:false},
		{title:'Lazo', field:'corrosionLoops-name', width:100,headerSort:false},
		{title:'Circuito', field:'circuits-name', width:80,headerFilterLiveFilter:false,headerFilter:true,headerFilterFunc:"=",headerSort:false},
		{title:'Cml', field:'cmls-number', width:50,headerFilterLiveFilter:false,headerFilter:true,headerFilterFunc:"="},
		{title:'Grupo', field:'groups-name', width:80,headerFilterLiveFilter:false,headerFilter:true},
		{title:'Tag Line',headerTooltip:"Tag de línea del cml según P&Id", field:'mylines-tag', width:100,headerFilter:false},
		{title:'Tipo',headerTooltip:"Tipo de accesorio", field:'cmlTypes-name',headerFilterLiveFilter:false, width:60,headerSort:false,headerFilter:true, headerFilterParams:{values:{"male":"Male", "female":"Female", "":""}}},
		{title:'Material', field:'tmls-materials-material_group',headerFilterLiveFilter:false, width:80,headerSort:false,headerFilter:true,headerFilterFunc:"like"},
		{title:'Especific.',headerTooltip:"Especificación de material del cml", field:'tmls-materials-name',headerFilterLiveFilter:false, width:80,headerSort:false,headerFilter:true,headerFilterFunc:"like"},
		{title:'Diam. 1 [inc]',headerTooltip:"Diametro mayor del cml", field:'diam_1', width:80,headerSort:false},
		{title:'Diam. 2 [inc]',headerTooltip:"Diametro menor del cml", field:'diam_2', width:80,headerSort:false},
		{title:'P. Dis [psig]',headerTooltip:"Presión de diseño", field:'cmls-des_press', width:80,headerSort:false},
		{title:'T. Dis [F]',headerTooltip:"Temperatura de diseño", field:'cmls-des_temp', width:80,headerSort:false},
		{title:'P. Op [psig]',headerTooltip:"Presión de operación", field:'cmls-op_press', width:80,headerSort:false},
		{title:'T. Op [F]',headerTooltip:"Temperatura de Operación", field:'cmls-op_temp', width:80,headerSort:false},
		{title:'CAR',headerTooltip:"Permisividad de corrosión", field:'cmls-car', width:50, formatter:"money", formatterParams:{
            decimal:",",
            thousand:"",
            symbol:"",
            symbolAfter:"",
            precision:3,
        }},
		{title:'CR Grupo [mpy]',headerTooltip:"Velocidad de Corrosión del grupo",tooltip:"Ver explicación", field:'groups-sel_cr', width:70, cssClass: 'bg-active text-dark', formatter:"money", formatterParams:{
            decimal:",",
            thousand:"",
            symbol:"",
            symbolAfter:"",
            precision:3,
        }},
		{title:'CR Mayor [mpy]',headerTooltip:"Velocidad de Corrosión Mayor del cml entre la de corto plazo y la de largo plazo",tooltip:"Ver explicación", field:'max_Sel_cr', width:70, cssClass: 'bg-active text-dark',formatter:"link", formatterParams:{label:labelCrMayor,target:"_blank",url:generateCmlCrExpLink}},
		{title:'CR LT [mpy]',headerTooltip:"Velocidad de corrosión de largo plazo del cml", field:'max_l_cr_tml', width:60, cssClass: 'bg-active text-dark',formatter:"money", formatterParams:{
            decimal:",",
            thousand:"",
            symbol:"",
            symbolAfter:"",
            precision:3,
        }},
		{title:'CR ST [mpy]',headerTooltip:"Velocidad de corrosión de corto plazo del cml", field:'max_s_cr_tml', width:60, cssClass: 'bg-active text-dark',formatter:"money", formatterParams:{
            decimal:",",
            thousand:"",
            symbol:"",
            symbolAfter:"",
            precision:3,
        }},
		{title:'Fecha Ult. Insp',headerTooltip:"Fecha de la última inspección registrada", field:'lastReadingDate', width:80, formatter:"datetime", formatterParams:{
            inputFormat:"YYYY-MM-DD",
            outputFormat:"DD-MM-YYYY",
            invalidPlaceholder:"",
        }},
		{title:'Ult. Esp. [in]',headerTooltip:"Espesor más bajo en la última inspección", field:'lastReadingThick', width:80,formatter:"money", formatterParams:{
            decimal:",",
            thousand:"",
            symbol:"",
            symbolAfter:"",
            precision:3,
        }},
		{title:'Fecha Ant. Insp',headerTooltip:"Fecha de anterior inspección válida", field:'BeforeLastReadingDate', width:80, formatter:"datetime", formatterParams:{
            inputFormat:"YYYY-MM-DD",
            outputFormat:"DD-MM-YYYY",
            invalidPlaceholder:"",
        }},
		//{title:'Ant. Esp. [in]', field:'BeforeLastReadingThick', width:80},
		{title:'Fecha Prim. Insp',headerTooltip:"Fecha de primera inspección válida", field:'OldestValidReadingDate', width:80, formatter:"datetime", formatterParams:{
            inputFormat:"YYYY-MM-DD",
            outputFormat:"DD-MM-YYYY",
            invalidPlaceholder:"",
        }},
		//{title:'Prim. Esp. [in]', field:'OldestValidReadingThick', width:80},
		{title:'Vida Rem. [Años]',headerTooltip:"Vida remanente en años a partir de hoy", field:'rem_life', width:80,headerSort:false, cssClass: 'bg-active text-dark'},
		{title:'Fecha Prox. Insp.',headerTooltip:"Fecha de cumplimiento de vida remanente", field:'next_i_date', width:80, cssClass: 'bg-active text-dark', formatter: "datetime", formatterParams:{
            inputFormat:"YYYY-MM-DD",
            outputFormat:"DD-MM-YYYY",
            invalidPlaceholder:"",
        }}
    ]
//Tabla de inspecciones
TableInspeccionesColumns = [ //Define Table Columns
    {title:'Circuito', field:'circuits-name', width:80,headerFilterLiveFilter:false,headerFilter:true,headerFilterFunc:"=",headerSort:false,frozen:true },
    {title:'Cml', field:'cmls-number', width:50,headerFilterLiveFilter:false,headerFilter:true,headerFilterFunc:"=",frozen:true },
    {title:'Departamento', field:'departments-name', width:120,headerSort:false},
    {title:'Unidad', field:'units-name', width:80,headerSort:false},
    {title:'Lazo', field:'corrosionLoops-name', width:100,headerSort:false}, 
    {title:'Tag Line',headerTooltip:"Tag de línea del cml según P&Id", field:'mylines-tag', width:100,headerFilter:false},
    {title:'Tipo',headerTooltip:"Tipo de accesorio", field:'cmlTypes-name',headerFilterLiveFilter:false, width:60,headerSort:false,headerFilter:true, headerFilterParams:{values:{"male":"Male", "female":"Female", "":""}}},
    {title:'Material', field:'tmls-materials-material_group',headerFilterLiveFilter:false, width:80,headerSort:false,headerFilter:true,headerFilterFunc:"like"},
    {title:'Especific.',headerTooltip:"Especificación de material del cml", field:'tmls-materials-name',headerFilterLiveFilter:false, width:80,headerSort:false,headerFilter:true,headerFilterFunc:"like"},
    {title:'Diam. 1 [inc]',headerTooltip:"Diametro mayor del cml", field:'diam_1', width:80,headerSort:false},
    {title:'Diam. 2 [inc]',headerTooltip:"Diametro menor del cml", field:'diam_2', width:80,headerSort:false},
    {title:'P. Dis [psig]',headerTooltip:"Presión de diseño", field:'cmls-des_press', width:80,headerSort:false},
    {title:'T. Dis [F]',headerTooltip:"Temperatura de diseño", field:'cmls-des_temp', width:80,headerSort:false},
    {title:'P. Op [psig]',headerTooltip:"Presión de operación", field:'cmls-op_press', width:80,headerSort:false},
    {title:'T. Op [F]',headerTooltip:"Temperatura de Operación", field:'cmls-op_temp', width:80,headerSort:false},
    {title:'1',headerTooltip:"Tml 1", field:'tmls-1', width:80,headerSort:false},
    {title:'2',headerTooltip:"Tml 1", field:'tmls-2', width:80,headerSort:false},
    {title:'3',headerTooltip:"Tml 1", field:'tmls-3', width:80,headerSort:false},
    {title:'4',headerTooltip:"Tml 1", field:'tmls-4', width:80,headerSort:false},
    {title:'5',headerTooltip:"Tml 1", field:'tmls-5', width:80,headerSort:false},
    {title:'6',headerTooltip:"Tml 1", field:'tmls-6', width:80,headerSort:false},
    {title:'7',headerTooltip:"Tml 1", field:'tmls-7', width:80,headerSort:false},
    {title:'8',headerTooltip:"Tml 1", field:'tmls-8', width:80,headerSort:false},
    {title:'9',headerTooltip:"Tml 1", field:'tmls-9', width:80,headerSort:false},
    {title:'10',headerTooltip:"Tml 1", field:'tmls-10', width:80,headerSort:false},
    {title:'11',headerTooltip:"Tml 1", field:'tmls-11', width:80,headerSort:false},
    {title:'12',headerTooltip:"Tml 1", field:'tmls-12', width:80,headerSort:false},
    {title:'13',headerTooltip:"Tml 1", field:'tmls-13', width:80,headerSort:false},
    {title:'14',headerTooltip:"Tml 1", field:'tmls-14', width:80,headerSort:false},
   
    
]
TableInspeccionesColumnsSimple = [ //Define Table Columns
    {title:'Circuito', field:'circuits-name', width:80,headerFilterLiveFilter:false,headerFilter:true,headerFilterFunc:"=",headerSort:false,frozen:true },
    {title:'Cml', field:'cmls-number', width:50,headerFilterLiveFilter:false,headerFilter:true,headerFilterFunc:"=",frozen:true },
    {title: 'Cml Id', field: 'cml_id', visible: true, width: 0},
    {title:'Departamento', field:'departments-name', width:120,headerSort:false},
    {title:'Unidad', field:'units-name', width:80,headerSort:false},
    {title:'Lazo', field:'corrosionLoops-name', width:100,headerSort:false}, 
    {title:'Tag Line',headerTooltip:"Tag de línea del cml según P&Id", field:'mylines-tag', width:100,headerFilter:false},
    {title:'Tipo',headerTooltip:"Tipo de accesorio", field:'cmlTypes-name',headerFilterLiveFilter:false, width:60,headerSort:false,headerFilter:true, headerFilterParams:{values:{"male":"Male", "female":"Female", "":""}}},
    {title:'Material', field:'tmls-materials-material_group',headerFilterLiveFilter:false, width:80,headerSort:false,headerFilter:true,headerFilterFunc:"like"},
    {title:'Especific.',headerTooltip:"Especificación de material del cml", field:'tmls-materials-name',headerFilterLiveFilter:false, width:80,headerSort:false,headerFilter:true,headerFilterFunc:"like"},
    {title:'Diam. [inc]',headerTooltip:"Diametro ", field:'tmls-nom_diam', width:80,headerSort:false},
    {title:'Esp. [inc]',headerTooltip:"Espesor ", field:'tmls-nom_thk', width:80,headerSort:false},
    {title:'Esp. Ret. [inc]',headerTooltip:"Espesor de retiro ", field:'tmls-ret_thk', width:80,headerSort:false},
    {title:'Tml',headerTooltip:"Tml number", field:'tmls-number', width:80,headerSort:false},
    {title:'Survey date',headerTooltip:"Fecha de inspección", field:'surveys-date', width:80,headerSort:true, formatter:"datetime", formatterParams:{
        inputFormat:"YYYY-MM-DD",
        outputFormat:"DD-MM-YYYY",
        invalidPlaceholder:"(invalid date)",
    }},
    {title:'Survey Reading',headerTooltip:"Valor obtenido", field:'surveys-reading', width:80,headerSort:true,formatter:"money", formatterParams:{
        decimal:",",
        thousand:"",
        symbol:"",
        symbolAfter:"",
        precision:3,
    }},
    {title:'Survey Type',headerTooltip:"Tipo de inspección", field:'SurveyTypes-name', width:80,headerSort:true},
    
]
function generateCmlCrExpLink(celda){
     var cellData = celda.getData();
    return "/cmls/cr_explanation/"+cellData.id
}

function labelCrMayor(celda){
    var cellData = celda.getData();
     return celda.getValue()=="&nbsb"?"":celda.getValue()
}
function loadTableDataExt(url_data, gid,clId,params_url = {tipoData:"CmlsComplete"}){
    $filtros = $("#filters").val();//En formato Json {name: , type: ,value:}
    $filtrosObj = JSON.parse($filtros);
    filter = []
    if (clId>0){
            filter.push({field:"CorrosionLoops.id",type:"=",value: clId})
    }
    if (gid>0){
            filter.push({field:"groups.id",type:"=",value: gid})
    }
    if((($filtrosObj||[]).length)){
        $filtrosObj.forEach(function (a) {
                    $optionN = a.name
                    $optionV = a.value
                    $optionT = a.type||a.operator
                    fType = ($optionT)? $optionT:"=";
                    if(typeof $optionV !== "undefined"){
                        filter.push({field:$optionN ,type:fType,value: $optionV})
                    }
                });
    }
    console.log(table_data.modules.ajax.url)
    if(table_data.modules.ajax.url!= ""){
        table_data.setFilter(filter);
    }else{
        //Cuando solo se define el filtro, no envía parámetros de ordenamiento ni paginator
        //table_data.setFilter(filter);
        table_data.modules.filter.filterList = filter
        table_data.replaceData(url_data,params_url)
        //table_data.modules.ajax.url = table_data.modules.ajax.urlGenerator(url_data,{},params_url);
        //table_data.setFilter(filter,params_url);
        //table_data.replaceData(url_data,params_url)
    }
}
function removeFilter(idToRemove){
    //alert(idToRemove)
    contenedorFiltros=$("#FiltersApplied_container")
    $filtros = $("#filters").val()||{};
    $filtrosObj = JSON.parse($filtros)||[];
    //Quitar filtro del json de filtros
    var isAlready = $filtrosObj.findIndex(obj => {
        return obj.id === idToRemove
    })
    $filtrosObj.splice(isAlready, 1);
    //$filtrosObj[isAlready]//Remueve el filtro
    $("#filters").val(JSON.stringify($filtrosObj))//Actualiza campo de Json
    //Actualiza la tabla de datos
    loadTableDataExt(url_data);
}
//cargar datos inciales
function updateFilters(AddedfilterObj,mode=1){
    contenedorFiltros=$("#FiltersApplied_container")
    $filtros = $("#filters").val()||{};//En formato Json {name: , type: ,value:}
    htmlAdded= `<div id="`+AddedfilterObj.id+`" style="margin-bottom:0px;display:block" class='alert alert-dismissible fade show btn btn-sm btn-light' role='alert'>
                    <div style='margin-right: 1.25rem'><b>`
                        +AddedfilterObj.popularName+`</b> `+AddedfilterObj.type+` `+AddedfilterObj.text+
                    `</div>
                    <input type="hidden" value="`
                        +AddedfilterObj.value+`" name="filter_value">
                    <input type="hidden" value="`
                        +AddedfilterObj.name+`" name="filter_name">
                    <button style="padding: 0 5px 0 0;" onclick='removeFilter("`+AddedfilterObj.id+`")' type='button' class='close' data-dismiss='alert' aria-label='Close'>
                        <span aria-hidden='true'>&times;</span>
                    </button>                        
                </div>`
    $filtrosObj = JSON.parse($filtros)||[];
    //Verificar si el filtro ya existe por nombre de filtro:
    var isAlready = $filtrosObj.findIndex(obj => {
        return obj.id === AddedfilterObj.id
    })
    
    mode = (isAlready>=0)? 2:1;
    if(isValidValue(AddedfilterObj.value)){ 
        if(mode == 1){//Agregar nuevo filtro
            $filtrosObj.push(AddedfilterObj)
            contenedorFiltros.append(htmlAdded)
        }else{//Update Filter
            $filtrosObj[isAlready] =AddedfilterObj
            //Quitar el filtro ya aplicado y poner el actual
            $('[id="'+AddedfilterObj.id+'"]').remove();
            contenedorFiltros.append(htmlAdded);
        }
        $("#filters").val(JSON.stringify($filtrosObj))
    }else{
        //Borrar si necesario
        if(mode == 2){
           $filtrosObj.splice(isAlready,1);
        }
        $('[id="'+AddedfilterObj.id+'"]').remove();
    }
}
function isValidValue(d) {
    if (typeof d === "undefined" || d=="Invalid Date" || d=="") return false 
    return true
}

// Recopila datos de la barra de filtros y los aplica
function getFilters(){
    did = $("#departments option:selected").val(); // Departamento Seleccionado
    uid = $("#unidades option:selected").val(); // Unidad Seleccionado
    gid = $("#grupos option:selected").val(); // Grupo Seleccionado
    clId = $("#corrosion_loop option:selected").val(); // Lazo Seleccionado
    tlId = $("#myline option:selected").val(); // linea Seleccionado
    d1Min = $("#diam1-min").val(); // D1 Min
    d1Max = $("#diam1-max").val(); // D1 Max
    api570Class = $("#api-570-class option:selected").text(); // API 570 class Text

    //ASP HSE
    asp_hs = $("#myline_hs").val(); // 
    asp_e = $("#myline_e").val(); // 
    asp_hsTxt = $("#myline_hs").val(); // 
    asp_eTxt= $("#myline_e").val(); // 

    // Estado de inspección
    surveyStatus = $("input[name='filters[inspectionStatus]']:checked").val(); // 
    idVal =$("input[name='filters[inspectionStatus]']:checked").attr("id");
    surveyStatusTxt = $("label[for='"+idVal+"']").text(); // 

    //caracteristicas
    opTempMin = $("#op-temp-min").val(); // Temp. Operacion
    opTempMax = $("#op-temp-max").val(); // 

    dTempMin = $("#d-temp-min").val(); // Temp. Diseñño
    dTempMax = $("#d-temp-max").val(); // 

    d2Min = $("#diam2-min").val(); // Diam 2
    d2Max = $("#diam2-max").val(); // 

    dMin = $("#diam-min").val(); // Diam 1
    dMax = $("#diam-max").val(); //

    crMin = $("#cr-min").val(); // cr min 
    crMax = $("#cr-max").val(); // cr max
    rlMin = $("#rl-min").val(); // rl min
    rlMax = $("#rl-max").val(); // rl max

    dtxt = $("#departments option:selected").text(); // Departamento Seleccionado
    utxt = $("#unidades option:selected").text(); // Unidad Seleccionado
    gtxt = $("#grupos option:selected").text(); // Grupo Seleccionado
    cltxt = $("#corrosion_loop option:selected").text(); // Lazo Seleccionado

    tltxt = $("#myline option:selected").text(); // Tag de linea Seleccionado
    mtrltxt= $("#materialSearchBox option:selected").text(); // Lazo Seleccionado

    stId = $("#surveysType option:selected").val(); // tipo de inspeccion Seleccionado
    stTxt = $("#surveysType option:selected").text(); // tipo de inspeccion Seleccionado
    
    survInspId = $("#Inspector option:selected").val(); // tipo de inspeccion Seleccionado
    survInspTxt = $("#Inspector option:selected").text(); // tipo de inspeccion Seleccionado

    survDateRangeVal = $("#survey_range_date").val()??'' // tipo de inspeccion Seleccionado
    survDateRangeArr = survDateRangeVal.split("-");
    survDateStart = Array.isArray(survDateRangeArr) ? survDateRangeArr[0] ??'': '';
    survDateEnd = Array.isArray(survDateRangeArr) ? survDateRangeArr[1]??'' : '';

    survCreationDateRange = $("#survey_range_creation_date").val()??''// tipo de inspeccion Seleccionado
    survCreationDateRangeArr = survCreationDateRange.split("-"); 
    survCreationDateStart = Array.isArray(survCreationDateRangeArr) ? survCreationDateRangeArr[0] ??'': '';
    survCreationDateEnd = Array.isArray(survCreationDateRangeArr) ? survCreationDateRangeArr[1]??'' : '';


     var sessionFilters = [
        {name: 'departments.id',type:'=',value: did, popularName: 'Departamento',text:dtxt,id:'f-departments.id', default:-1},
        {name: 'units.id',type:'=',value: uid, popularName: 'Unidad',text:utxt,id:'f-units.id', default:-1},
        {name: 'corrosionLoops.id',type:'=',value:clId, popularName: 'Lazo de Corrosion',text:cltxt,id:'f-corrosionLoops.id', default:-1},
        {name: 'groups.id',type:'=',value: gid, popularName: 'Grupo',text:gtxt,id:'f-groups.id', default:-1},
     ]
    var otherFilters=[
         {name: 'mylines.id',type:'=',value: tlId, popularName: 'Tag Línea',text:tltxt,id:'f-mylines.id', default:-1},
         {name: 'mylines.api570_class',type:'=',value: api570Class, popularName: 'Clase API',text:api570Class, id:'f-mylines.api570_class', default:-1},
         {name: 'materials.material_group',type:'like',value: mtrltxt, popularName: 'Clase de Material',text:mtrltxt,id:'f-material_group', default:-1},
         {name: 'diam_1',type:'>=',value: d1Min, popularName: 'Diam Mayor Min',text:d1Min +"[inc]",id:'f-d1-min', default:-1},
         {name: 'diam_1',type:'<=',value: d1Max, popularName: 'Diam Mayor Max',text:d1Max +"[inc]",id:'f-d1-max', default:-1},
         {name: 'diam_2',type:'>=',value: d2Min, popularName: 'Diam Menor Min',text:d2Min +"[inc]",id:'f-d2-min', default:-1},
         {name: 'diam_2',type:'<=',value: d2Max, popularName: 'Diam Menor Max',text:d2Max +"[inc]",id:'f-d2-max', default:-1},
         {name: 'tmls.nom_diam',type:'>=',value: dMin, popularName: 'Diam Min',text:dMin +"[inc]",id:'f-d-min', default:-1},
         {name: 'tmls.nom_diam',type:'<=',value: dMax, popularName: 'Diam Max',text:dMax +"[inc]",id:'f-d-max', default:-1},
         {name: 'cmls.op_temp',type:'>=',value: opTempMin, popularName: 'Temp. Op. Min',text:opTempMin +"[F]",id:'f-opTemp-min', default:-1},
         {name: 'cmls.op_temp',type:'<=',value: opTempMax, popularName: 'Temp. Op. Max',text:opTempMax +"[F]",id:'f-opTemp-max', default:-1},
         {name: 'cmls.des_temp',type:'>=',value: dTempMin, popularName: 'Temp. Op. Min',text:dTempMin +"[F]",id:'f-dTemp-min', default:-1},
         {name: 'cmls.des_temp',type:'<=',value: dTempMax, popularName: 'Temp. Op. Max',text:dTempMax +"[F]",id:'f-dTemp-max', default:-1},
     ]
    hoy = new Date();         
    minFechaVR = (rlMin!="" && rlMin !=-100)?add_years(new Date(),parseFloat(rlMin)):null;
    maxFechaVR = (rlMax!=""&& rlMin !=-100)?add_years(new Date(),parseFloat(rlMax)):null;


     var integrityFilters=[
         {name: 'max_Sel_cr',type:'>=',value: crMin, popularName: 'Cr.',text:crMin +' [mpy]',id:'f-cr-min', default:-1},
         {name: 'max_Sel_cr',type:'<=',value: crMax, popularName: 'Cr.',text:crMax +' [mpy]',id:'f-cr-max', default:-1},
         {name: 'cmls_rem_life_date',type:'>=',value: minFechaVR, popularName: 'VUR.',text:rlMin +' [años]',id:'f-rl-min', default:-1},
         {name: 'cmls_rem_life_date',type:'<=',value: maxFechaVR, popularName: 'VUR.',text:rlMax +' [años]',id:'f-rl-max', default:-1},
         {name: 'lastReadingDate',type:'>',value: surveyStatus, popularName: 'Estado Inspección',text:surveyStatusTxt ,id:'f-survStatus', default:-1},
     ]

     var aspFilters=[
        {name: 'mylines.asp_hs',type:'=',value: asp_hs, popularName: 'ASP Salud y Seg.',text:asp_hsTxt ,id:'asp-hs', default:''},
        {name: 'mylines.asp_e',type:'=',value: asp_e, popularName: 'ASP Amb.',text:asp_eTxt, id:'asp-e', default:''},
    ]

     var surveysFilters=[
        {name: 'surveyTypes.id',type:'=',value: stId, popularName: 'Tipo Inspección.',text: stTxt ,id:'f-surveyType', default:-1},
        {name: 'surveys.inspector_user_id',type:'=',value: survInspId, popularName: 'Inspector',text: survInspTxt ,id:'f-surveyInspector', default:-1},
        {name: 'surveys.date',type:'>=',value: survDateStart, popularName: 'Fecha Inicio',text: survDateStart ,id:'f-surveyStartDate', default:-1},
        {name: 'surveys.date',type:'<=',value: survDateEnd, popularName: 'Fecha fin',text: survDateEnd ,id:'f-surveyEndDate', default:-1},
        {name: 'surveys.creation_date',type:'>=',value: survCreationDateStart, popularName: 'Fecha de creacion inicio',text: survCreationDateStart ,id:'f-surveyCreationStartDate', default:-1},
        {name: 'surveys.creation_date',type:'<=',value: survCreationDateEnd, popularName: 'Fecha de creación fin',text: survCreationDateEnd ,id:'f-surveyCreationEndDate', default:-1},
    ]
     
    sessionFilters.forEach(function(a){
        //if(a.value>=0){ 
            updateFilters(a,1)
        //}
    });
    otherFilters.forEach(function(a){
        if((a.value>0 || a.value != "") && a.value != a.default){ 
            updateFilters(a,1)
        }
    });
    integrityFilters.forEach(function(a){
        if((a.value!="" && a.value!=null) && a.value != a.default){ 
            updateFilters(a,1)
        }
    });
    surveysFilters.forEach(function(a){
        if((a.value!="" && a.value!=null) && a.value != a.default){ 
            updateFilters(a,1)
        }
    });
    // Filtros por ASP
    aspFilters.forEach(function(a){
        if((a.value!="" && a.value!=null) && a.value != a.default){ 
            updateFilters(a,1)
        }
    });
}
//Helpers functions

//Date
function add_years(dt,n) 
 {
    return new Date(dt.setFullYear(dt.getFullYear() + n));      
 }
function ConfirmDialog(message) {
    $('<div></div>').appendTo('body')
    .html('<div><h6>'+message+'?</h6></div>')
    .dialog({
        modal: true, title: 'Delete message', zIndex: 10000, autoOpen: true,
        width: 'auto', resizable: false,
        buttons: {
            Yes: function () {
                // $(obj).removeAttr('onclick');                                
                // $(obj).parents('.Parent').remove();
                $(this).dialog("close");
                return true;
            },
            No: function () {                                                                 
               $(this).dialog("close");
                return false;
            }
        },
        close: function (event, ui) {
            $(this).remove();
        }
    });
};
